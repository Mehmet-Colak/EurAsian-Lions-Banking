const originalBox = document.querySelector("#original");
const interestRateBox = document.querySelector("#interestRate");
const xiceAYearBox = document.querySelector("#xiceAYear");
const yearsBox = document.querySelector("#years");

const totalMoneyOutput = document.querySelector("#totalMoney");
const moneyEarnedOutput = document.querySelector("#moneyEarned");

originalBox.addEventListener("input", updateinterest);
interestRateBox.addEventListener("input", updateinterest);
xiceAYearBox.addEventListener("input", updateinterest);
yearsBox.addEventListener("input", updateinterest);

function updateBMI() {
  const pounds = Number(weightBox.value);
  const inches = Number(heightBox.value);
  const kilograms = pounds * KILOGRAMS_PER_POUND;
  const meters = inches * METERS_PER_INCH;
  const bmi = kilograms / (meters * meters);
  bmiOutput.textContent = `The bmi is ${bmi.toFixed(2)}`;
}

function updateinterest() {
  const original = Number(originalBox.value);
  const interestRate = Number(interestRateBox.value);
  const xiceAYear = Number(xiceAYearBox.value);
  const years = Number(yearsBox.value);
  const totalMoney =
    original * (1 + interestRate / xiceAYear) ** (xiceAYear * years);
  const moneyEarned = totalMoney - original;
  totalMoneyOutput.textContent = `The total money earned is ${totalMoney.toFixed(
    2
  )}`;
  moneyEarnedOutput.textContent = `Your profit is ${moneyEarned.toFixed(2)}`;
}
